package me.aldy.mycp.entity;

import android.database.Cursor;
import android.os.Parcel;
import android.os.Parcelable;

import me.aldy.mycp.db.DatabaseContract;

import static me.aldy.mycp.db.DatabaseContract.getColumnInt;
import static me.aldy.mycp.db.DatabaseContract.getColumnFloat;
import static me.aldy.mycp.db.DatabaseContract.getColumnString;

public class MovieItem implements Parcelable {
    private int id;
    private String title, overview, release, genre, poster, type;
    private float rating;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getOverview() {
        return overview;
    }

    public void setOverview(String overview) {
        this.overview = overview;
    }

    public String getRelease() {
        return release;
    }

    public void setRelease(String release) {
        this.release = release;
    }

    public String getGenre() {
        return genre;
    }

    public void setGenre(String genre) {
        this.genre = genre;
    }

    public String getPoster() {
        return poster;
    }

    public void setPoster(String poster) {
        this.poster = poster;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public float getRating() {
        return rating;
    }

    public void setRating(float rating) {
        this.rating = rating;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(this.id);
        dest.writeString(this.title);
        dest.writeString(this.overview);
        dest.writeString(this.release);
        dest.writeString(this.genre);
        dest.writeString(this.poster);
        dest.writeString(this.type);
        dest.writeFloat(this.rating);
    }

    public MovieItem() {
    }

    public MovieItem(int id, String title, String overview, String release, String genre, String poster, String type, float rating) {
        this.id = id;
        this.title = title;
        this.overview = overview;
        this.release = release;
        this.genre = genre;
        this.poster = poster;
        this.type = type;
        this.rating = rating;
    }

    public MovieItem(Cursor cursor){
        this.id = getColumnInt(cursor, DatabaseContract.FavColumns._ID);
        this.title = getColumnString(cursor, DatabaseContract.FavColumns.TITLE);
        this.overview = getColumnString(cursor, DatabaseContract.FavColumns.OVERVIEW);
        this.release = getColumnString(cursor, DatabaseContract.FavColumns.RELEASE_DATE);
        this.genre = getColumnString(cursor, DatabaseContract.FavColumns.GENRE);
        this.poster = getColumnString(cursor, DatabaseContract.FavColumns.POSTER);
        this.type = getColumnString(cursor, DatabaseContract.FavColumns.TYPE);
        this.rating = getColumnFloat(cursor, DatabaseContract.FavColumns.RATING);
    }

    protected MovieItem(Parcel in) {
        this.id = in.readInt();
        this.title = in.readString();
        this.overview = in.readString();
        this.release = in.readString();
        this.genre = in.readString();
        this.poster = in.readString();
        this.type = in.readString();
        this.rating = in.readFloat();
    }

    public static final Parcelable.Creator<MovieItem> CREATOR = new Parcelable.Creator<MovieItem>() {
        @Override
        public MovieItem createFromParcel(Parcel source) {
            return new MovieItem(source);
        }

        @Override
        public MovieItem[] newArray(int size) {
            return new MovieItem[size];
        }
    };
}
