package me.aldy.mycp;

import android.database.Cursor;

public interface LoadMoviesCallback {
    void postExecute(Cursor movie);
}
