package me.aldy.mycp.adapter;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;

import java.util.ArrayList;

import me.aldy.mycp.R;
import me.aldy.mycp.entity.MovieItem;

import static me.aldy.mycp.db.DatabaseContract.FavColumns.CONTENT_URI;

public class MyAdapter extends RecyclerView.Adapter<MyAdapter.CardViewViewHolder> {
    private final ArrayList<MovieItem> listMovies = new ArrayList<>();
    private final Activity activity;

    private OnItemClickCallback onItemClickCallback;

    public interface OnItemClickCallback{
        void onItemClicked(MovieItem movie);
    }

    public void setOnItemClickCallback(OnItemClickCallback onItemClickCallback){
        this.onItemClickCallback = onItemClickCallback;
    }

    public ArrayList<MovieItem> getListMovies() {
        return listMovies;
    }

    public MyAdapter(Activity activity) {
        this.activity = activity;
    }

    public void setListMovies(ArrayList<MovieItem> listMovies) {
        this.listMovies.clear();
        this.listMovies.addAll(listMovies);
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public CardViewViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_movie, parent, false);
        return new CardViewViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final CardViewViewHolder holder, int position) {
        holder.tv_title.setText(getListMovies().get(position).getTitle());
        holder.tv_overview.setText(getListMovies().get(position).getOverview());
        holder.tv_genre.setText(holder.itemView.getContext().getString(R.string.label_genre, getListMovies().get(position).getGenre()));
        holder.ratingBar.setRating((getListMovies().get(position).getRating() / 2));
        holder.tv_rating.setText(String.valueOf(getListMovies().get(position).getRating()));
        Glide.with(holder.itemView.getContext())
                .load("https://image.tmdb.org/t/p/w185/"+getListMovies().get(position).getPoster())
                .centerCrop()
                .apply(new RequestOptions().override(120, 220))
                .into(holder.img_poster);

//        holder.itemView.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                onItemClickCallback.onItemClicked(getListMovies().get(holder.getAdapterPosition()));
//            }
//        });
    }

    @Override
    public int getItemCount() {
        return listMovies.size();
    }

    public class CardViewViewHolder extends RecyclerView.ViewHolder {
        TextView tv_title, tv_overview, tv_genre, tv_rating;
        ImageView img_poster;
        RatingBar ratingBar;

        public CardViewViewHolder(@NonNull View itemView) {
            super(itemView);

            tv_title = itemView.findViewById(R.id.tv_title);
            tv_overview = itemView.findViewById(R.id.tv_overview);
            tv_genre = itemView.findViewById(R.id.tv_genre);
            tv_rating = itemView.findViewById(R.id.tv_rating);
            img_poster = itemView.findViewById(R.id.imageview_poster);
            ratingBar = itemView.findViewById(R.id.ratingbar);
        }
    }
}
