package me.aldy.mycp;

import android.database.Cursor;

import java.util.ArrayList;

import me.aldy.mycp.entity.MovieItem;

import static android.provider.BaseColumns._ID;
import static me.aldy.mycp.db.DatabaseContract.FavColumns.GENRE;
import static me.aldy.mycp.db.DatabaseContract.FavColumns.OVERVIEW;
import static me.aldy.mycp.db.DatabaseContract.FavColumns.POSTER;
import static me.aldy.mycp.db.DatabaseContract.FavColumns.RATING;
import static me.aldy.mycp.db.DatabaseContract.FavColumns.RELEASE_DATE;
import static me.aldy.mycp.db.DatabaseContract.FavColumns.TITLE;
import static me.aldy.mycp.db.DatabaseContract.FavColumns.TYPE;

public class MappingHelper {
    public static ArrayList<MovieItem> mapCursorToArrayList(Cursor moviesCursor) {
        ArrayList<MovieItem> moviesList = new ArrayList<>();

        while (moviesCursor.moveToNext()) {
            int id = moviesCursor.getInt(moviesCursor.getColumnIndexOrThrow(_ID));
            float rating = moviesCursor.getFloat(moviesCursor.getColumnIndexOrThrow(RATING));
            String title = moviesCursor.getString(moviesCursor.getColumnIndexOrThrow(TITLE));
            String overview = moviesCursor.getString(moviesCursor.getColumnIndexOrThrow(OVERVIEW));
            String release = moviesCursor.getString(moviesCursor.getColumnIndexOrThrow(RELEASE_DATE));
            String genre = moviesCursor.getString(moviesCursor.getColumnIndexOrThrow(GENRE));
            String poster = moviesCursor.getString(moviesCursor.getColumnIndexOrThrow(POSTER));
            String type = moviesCursor.getString(moviesCursor.getColumnIndexOrThrow(TYPE));
            moviesList.add(new MovieItem(id, title, overview, release, genre, poster, type, rating));
        }

        return moviesList;
    }
}
